/*
 * goertzel.c
 *
 *  Created on: May 1, 2022
 *      Author: Ryan Tsang
 */

#include "goertzel.h"

#include <stdint.h>

#define N_TONES 8

/**
 * Goertzel Coefficients
 *
 * Calculated as 
 * coeff = 2 * cos( 2π * tfreq / sfreq )
 * where
 *     tfreq    = target frequency
 *     sfreq
 */
int32_t fp_coeff_lut[N_TONES] = {
    31548, // 697
    31281, // 770
    30951, // 852
    30556, // 941
    29144, // 1209
    28361, // 1336
    27409, // 1477
    26258  // 1633
};


/**
 * Goertzel Algorithm Implementation
 *
 * based on https://github.com/OmaymaS/DTMF-Detection-Goertzel-Algorithm-
 * @param samples[]     collected time series samples to process
 * @param coeff_idx     goertzel coefficient lookup table index
 * @param N             number of samples
 * @return              32-bit fixed point squared magnitude (power) of the target tone
 *                        in the given sampling window
 */
int32_t goertzel_pow(int16_t samples[], int32_t coeff_idx, int32_t N) {
    // declare and initialize variables
    int32_t Q0, Q1 = 0, Q2 = 0, i;
    int32_t prod1, prod2, prod3, pow = 0;

    for (i = 0; i < N; i++) {
        // loop N times and calculate Q0, Q1, Q2 in each iteration
        // 12 bit shift to account for fixed point
        Q0 = (samples[i]) + ((fp_coeff_lut[coeff_idx] * Q1) >> 14) - Q2;
        Q2 = Q1;
        Q1 = Q0;
    }

    // calculate products for power spectrum based on wikipedia
    // https://en.wikipedia.org/wiki/Goertzel_algorithm#Power-spectrum_terms
    prod1 = Q1 * Q1;
    prod2 = Q2 * Q2;
    prod3 = ((Q1 * fp_coeff_lut[coeff_idx]) >> 14) * Q2;

    pow = (prod1 + prod2 - prod3);

    return pow;
}


