#!/usr/bin/env python
# 
# A short python script to generate Goertzel Coefficients for DTMF

from math import cos, pi

sfreq = 16000 # sampling frequency
# dtmf_tones = [697, 770, 852, 941, 1209, 1336, 1477, 1633]
dtmf_tones = [100, 200, 300, 400, 500, 600, 700, 800]
fp_frac_bits = 14 # number of fixed point fractional bits

coeffs = [2 * cos(2 * pi * (tone / sfreq)) for tone in dtmf_tones]
fp_coeffs = [int(round(c * (1 << fp_frac_bits))) for c in coeffs]

print("DTMF Tones: {{{}}}".format(', '.join([str(tone) for tone in dtmf_tones])))
print("Goertzel Coeffs: {{{}}}".format(', '.join([str(c) for c in coeffs])))
print("Fixed Point Coeffs: {{{}}}".format(', '.join([str(c) for c in fp_coeffs])))