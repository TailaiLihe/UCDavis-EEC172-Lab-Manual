/*
 * goertzel.h
 *
 * the goertzel algorithm for computing the discrete fourier transform coefficients
 * using fixed point arithmetic
 *
 * a very clever sine function approximation taken from here:
 * https://www.nullhardware.com/blog/fixed-point-sine-and-cosine-for-embedded-systems/
 *
 *  Created on: May 1, 2022
 *      Author: Ryan Tsang
 */

#ifndef GOERTZEL_H_
#define GOERTZEL_H_

#include <stdint.h>

/**************************************************
 * GLOBAL VARIABLES AND CONSTANTS
 **************************************************/

/**************************************************/

/**
 * Floating Point Sine Function
 *
 * Taken from https://www.nullhardware.com/blog/fixed-point-sine-and-cosine-for-embedded-systems/
 * Implements 5-th order polynomial approximation to sin(x)
 * Uses 16-bit (4.12) fixed point representation
 *
 * @param w    angle (2^15 units in the circle [0, 0x8000] -> [0, 2pi])
 *                 note that we never use 0x8000, since 0 == 2pi in trig
 *                 we actually only go up to 0x7FFF.
 *                 this also means that 0x4000 == pi
 * @return     16 bit fixed point sine value (-> +0x1000 = +1, -0x1000 = -1)
 */
int16_t sin_fp(int16_t w);

/**
 * Floating Point Cosine Function
 *
 * Uses the Trig Identity cos(x) = sin(x + pi / 2)
 */
int16_t cos_fp(int16_t w);


/**
 * Helper Function to calculate coefficients for Goertzel Algorithm
 *
 * @param freq      target freqency
 * @param sfreq     sampling freqency
 * @return          32-bit fixed point Goertzel coefficient
 *                    (12 fractional bits)
 */
int32_t goertzel_coeff(int32_t freq, int32_t sfreq);

/**
 * Goertzel Algorithm Implementation
 *
 * based on https://github.com/OmaymaS/DTMF-Detection-Goertzel-Algorithm-
 * @param samples[]     collected time series samples to process
 * @param freq          target frequency
 * @param sfreq         sampling frequency
 * @param N             number of samples
 * @return              32-bit fixed point squared magnitude (power) of the target tone
 *                        in the given sampling window
 */
int32_t goertzel_pow(int16_t samples[], int32_t coeff, int32_t N);

#endif /* GOERTZEL_H_ */
