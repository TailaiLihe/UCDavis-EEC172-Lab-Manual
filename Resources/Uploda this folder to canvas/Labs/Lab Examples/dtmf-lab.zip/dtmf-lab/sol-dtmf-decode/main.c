//*****************************************************************************
//
// Application Name     - EEC172-SQ22 - Lab 4 - DTMF Decode Solution
// Application Overview - Solution to decoding DTMF for Lab 4
//
//*****************************************************************************

// Standard includes
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

// Driverlib includes
#include "hw_types.h"
#include "hw_memmap.h"
#include "hw_common_reg.h"
#include "hw_ints.h"
#include "rom.h"
#include "rom_map.h"
#include "prcm.h"
#include "interrupt.h"
#include "utils.h"
#include "timer.h"
#include "spi.h"
#include "gpio.h"
#include "uart.h"

// Custom Includes
#include "goertzel.h"

// Common interface includes
#include "timer_if.h"
#include "uart_if.h"
#include "pin_mux_config.h"

/**
 * Pin Config
 *
 * PIN_08 - ADC Chip Select
 * PIN_45 - SPI CLK
 * PIN_06 - SPI CIPO
 * PIN_07 - SPI COPI
 * PIN_55 - UART TX
 * PIN_57 - UART RX
 */

//*****************************************************************************
//                 GLOBAL VARIABLES -- Start
//*****************************************************************************

// GPIO Pin Struct
typedef struct GPIOPin_t {
    unsigned long port;
    unsigned int pin;
} GPIOPin_t;

typedef union ADCData_t {
    uint16_t data;
    uint8_t buf[2];
} ADCData_t;

// ADC CS Pin (PIN_08)
static GPIOPin_t adc_cs = { .port = GPIOA2_BASE, .pin = 0x2 };

// ADC Data union
static ADCData_t adc_data = { .data = 0 };


// Global Variables to pass to Goertzel Algorithm

#define BLOCK_SIZE_N    410   // number of samples
#define SFREQ           16000 // sampling frequency
#define N_TONES         8

uint32_t f_tones[N_TONES] = { 697, 770, 852, 941, 1209, 1336, 1477, 1633 };
uint32_t coeff[N_TONES];        // goertzel coefficients
uint32_t pow_tones[N_TONES];    // power spectrum of target tones

volatile int16_t samples[BLOCK_SIZE_N];
static volatile int8_t  flag_block_full = 0;

#define SPI_IF_BIT_RATE  500000
#define TR_BUFF_SIZE     100

#define ADC_TIMER_BASE  TIMERA0_BASE
#define ADC_TIMER       TIMER_A
#define ADC_READ_PERIOD 5000 // in ticks

static unsigned char g_ucTxBuff[TR_BUFF_SIZE];
static unsigned char g_ucRxBuff[TR_BUFF_SIZE];
static unsigned char ucTxBuffNdx;
static unsigned char ucRxBuffNdx;

#if defined(ccs)
extern void (* const g_pfnVectors[])(void);
#endif
#if defined(ewarm)
extern uVectorEntry __vector_table;
#endif


//*****************************************************************************
//                 GLOBAL VARIABLES -- End
//*****************************************************************************

//*****************************************************************************
//                 HELPER FUNCTIONS -- Start
//*****************************************************************************

/**
 * helper function to flip endianness
 */
//static inline uint16_t reverse_bits(uint16_t v) {
//    v = (v & 0xFF00) >> 8 | (v & 0x00FF) << 8;
//    v = (v & 0xF0F0) >> 4 | (v & 0x0F0F) << 4;
//    v = (v & 0xCCCC) >> 2 | (v & 0x3333) << 2;
//    v = (v & 0xAAAA) >> 1 | (v & 0x5555) << 1;
//    return v;
//}

/**
 * MCP3001 Get
 *
 * Receive data from MCP3001 and format into 16bit value
 */
int16_t MCP3001Get() {

    // chip select enable
    GPIOPinWrite(adc_cs.port, adc_cs.pin, 0);

    // initiate spi transfer of 2 bytes
    MAP_SPITransfer(GSPI_BASE, g_ucTxBuff, adc_data.buf,2,
            SPI_CS_ENABLE|SPI_CS_DISABLE);

    // chip select disable
    GPIOPinWrite(adc_cs.port, adc_cs.pin, adc_cs.pin);

    // data comes in format
    // | ? | ? | 0 | B9 | B8 | B7 | B6 | B5 | ... | B4 | B3 | B2 | B1 | B0 | B1 | B2 | B3 |

    // bytes get read in little endian, so need to swap them first
    adc_data.data = (adc_data.data & 0xFF00) >> 8 | (adc_data.data & 0x00FF) << 8;

    // process data to return
    adc_data.data &= 0x1FF8;
    adc_data.data >>= 3;

//    Report("Data In: %x\n\r", adc_data.data);

    return adc_data.data;
}


//*****************************************************************************
//                 HELPER FUNCTIONS -- End
//*****************************************************************************

//*****************************************************************************
//                 INTERRUPT HANDLERS -- Start
//*****************************************************************************

/**
 * Timer Interrupt Handler
 */
void ADCReadTimerHandler(void) {
    static uint16_t sample_idx = 0;

    // clear timer interrupt
    Timer_IF_InterruptClear(TIMERA0_BASE);

    // store ADC data in sample block
    samples[sample_idx++] = MCP3001Get();

    // check if block full
    if (sample_idx >= BLOCK_SIZE_N) {
        sample_idx = 0;
        flag_block_full = 1;
        Timer_IF_Stop(ADC_TIMER_BASE, ADC_TIMER);
    }

}

//*****************************************************************************
//                 INTERRUPT HANDLERS -- End
//*****************************************************************************

//*****************************************************************************
//                 INIT FUNCTIONS -- Start
//*****************************************************************************

/**
 * SPI Init
 *
 * Initializes the SPI module, needs to be called before AdafruitInit
 */
void SPIInit() {
    // reset spi
    MAP_SPIReset(GSPI_BASE);

    // configure spi interface
    MAP_SPIConfigSetExpClk(GSPI_BASE,MAP_PRCMPeripheralClockGet(PRCM_GSPI),
                   SPI_IF_BIT_RATE,SPI_MODE_MASTER,SPI_SUB_MODE_0,
                   (SPI_SW_CTRL_CS |
                   SPI_4PIN_MODE |
                   SPI_TURBO_OFF |
                   SPI_CS_ACTIVEHIGH |
                   SPI_WL_8));

    // enable spi for communication
    MAP_SPIEnable(GSPI_BASE);

    Message("Enabled SPI Interface in Master Mode\n\r");

    // initialize chip select pins
    // ADC is active low
    GPIOPinWrite(adc_cs.port, adc_cs.pin, adc_cs.pin);
}


/**
 * MCP3001 Timer Start
 */
void MCP3001TimerStart(void) {
    // set timer period in ticks
    // (interface uses ms, but 16kHz -> 0.0625ms and we can't use float)
    MAP_TimerLoadSet(ADC_TIMER_BASE, ADC_TIMER, ADC_READ_PERIOD);

    // start timer
    MAP_TimerEnable(ADC_TIMER_BASE, ADC_TIMER);
}

/**
 * MCP3001 Timer Init
 *
 * Initializes Timer module and starts ADC Timer
 */
void MCP3001TimerInit(void) {
    // configure timer
    Timer_IF_Init(PRCM_TIMERA0, ADC_TIMER_BASE, TIMER_CFG_PERIODIC, ADC_TIMER, 0);
    // Timer_IF_Init(PRCM_TIMERA0, ADC_TIMER_BASE, TIMER_CFG_ONE_SHOT, ADC_TIMER, 0);

    // register interrupt for reading ADC
    Timer_IF_IntSetup(ADC_TIMER_BASE, ADC_TIMER, ADCReadTimerHandler);

    // start timer
    MCP3001TimerStart();
}


/**
 * Initialize for Signal Processing
 */
void GoertzelInit(void) {
    int i;
    // initialize coefficients
    for (i = 0; i < N_TONES; i++) {
        coeff[i] = goertzel_coeff(f_tones[i], SFREQ);
    }
}


//*****************************************************************************
//                 INIT FUNCTIONS -- End
//*****************************************************************************


//*****************************************************************************
//
//! Board Initialization & Configuration
//!
//! \param  None
//!
//! \return None
//
//*****************************************************************************
static void
BoardInit(void)
{
/* In case of TI-RTOS vector table is initialize by OS itself */
#ifndef USE_TIRTOS
  //
  // Set vector table base
  //
#if defined(ccs)
    MAP_IntVTableBaseSet((unsigned long)&g_pfnVectors[0]);
#endif
#if defined(ewarm)
    MAP_IntVTableBaseSet((unsigned long)&__vector_table);
#endif
#endif
    //
    // Enable Processor
    //
    MAP_IntMasterEnable();
    MAP_IntEnable(FAULT_SYSTICK);

    PRCMCC3200MCUInit();
}

//*****************************************************************************
//
//! Main function for spi demo application
//!
//! \param none
//!
//! \return None.
//
//*****************************************************************************
void main()
{
    //
    // Initialize Board configurations
    //
    BoardInit();

    //
    // Muxing UART and SPI lines.
    //
    PinMuxConfig();

    //
    // Enable the SPI module clock
    //
    MAP_PRCMPeripheralClkEnable(PRCM_GSPI,PRCM_RUN_MODE_CLK);

    //
    // Initialising the Terminal.
    //
    InitTerm();

    //
    // Clearing the Terminal.
    //
    ClearTerm();

    //
    // Display the Banner
    //
    Message("\n\n\n\r");
    Message("\t\t   ********************************************\n\r");
    Message("\t\t        DTMF Decode Application  \n\r");
    Message("\t\t   ********************************************\n\r");
    Message("\n\n\n\r");

    //
    // Reset the peripheral
    //
    MAP_PRCMPeripheralReset(PRCM_GSPI);

    SPIInit();

    GoertzelInit();

    MCP3001TimerInit();

    int i;
    uint32_t sum, avg;
    while(1) {
        if (flag_block_full) {
            // process block when full
            // remove DC bias from block
            sum = 0;
            for (i = 0; i < BLOCK_SIZE_N; i++) {
                sum += samples[i];
            }
            avg = sum / BLOCK_SIZE_N;
            for (i = 0; i < BLOCK_SIZE_N; i++) {
                samples[i] -= (int16_t) avg;
            }

            // compute power spectrum with goertzel
            for (i = 0; i < N_TONES; i++) {
                // calculate power of each frequency
                pow_tones[i] = goertzel_pow((int16_t *) samples, coeff[i], BLOCK_SIZE_N);
            }

            // print power spectrum
            for (i = 0; i < N_TONES; i++) {
                Report("{ %d:%07d } ", f_tones[i], pow_tones[i] >> 12);
            }
            Message("\n\r");

            // restart timer when done
            MCP3001TimerStart();
            flag_block_full = 0;
        }
    }

}

