/*
 * goertzel.c
 *
 *  Created on: May 1, 2022
 *      Author: Ryan Tsang
 */

#include "goertzel.h"

#include <stdint.h>


/**
 * Floating Point Sine Function
 *
 * Taken from https://www.nullhardware.com/blog/fixed-point-sine-and-cosine-for-embedded-systems/
 * Implements 5-th order polynomial approximation to sin(x)
 * Uses 16-bit (4.12) fixed point representation
 *
 * @param w    angle (2^15 units in the circle [0, 0x8000] -> [0, 2pi])
 *                 note that we never use 0x8000, since 0 == 2pi in trig
 *                 we actually only go up to 0x7FFF.
 *                 this also means that 0x4000 == pi
 * @return     16 bit fixed point sine value (-> +0x1000 = +1, -0x1000 = -1)
 */
int16_t sin_fp(int16_t w) {

    /**************************************************
     * Curve is fit to region [0, pi/2]
     * Convert signed input to a value between 0 and 0x2000 (8192) -> pi / 2
     */

    w <<= 1;
    uint8_t carry = w < 0; // set the carry bit for the output

    // check if angle greater than or equal to pi and if so,
    // flip the input value to correspond to [0, 0x2000] range
    // doesn't affect 0x4000 itself
    if (w & 0x4000) {
        w = ((1 << 15) - w);
    }

    w = (w & 0x7FFF) >> 1;

    /**************************************************/

    /**************************************************
     * Implement the polynomial formula
     *  = y * 2^-n * ( A1 - 2^(q-p)* y * 2^-n * y * 2^-n * [B1 - 2^-r * y * 2^-n * C1 * y]) * 2^(a-q)
     */

    enum {n = 13, p = 32, q = 31, r = 3, a = 12};
    enum {
        A1 = 3370945099UL,
        B1 = 2746362156UL,
        C1 = 292421UL
    };

    uint32_t y = (C1 * ((uint32_t) w)) >> n;
    y = B1 - (((uint32_t) w * y) >> r);
    y = ((uint32_t) w) * (y >> n);
    y = ((uint32_t) w) * (y >> n);
    y = A1 - (y >> (p - q));
    y = ((uint32_t) w) * (y >> n);
    y = (y + (1UL << (q - a - 1))) >> (q - a); // rounding

    return carry ? -y : y;
}


/**
 * Floating Point Cosine Function
 *
 * Uses the Trig Identity cos(x) = sin(x + pi / 2)
 */
int16_t cos_fp(int16_t w) {
    return sin_fp(w + 0x2000U);
}


/**
 * Helper Function to calculate coefficients for Goertzel Algorithm
 *
 * @param freq      target freqency
 * @param sfreq     sampling freqency
 * @return          32-bit fixed point Goertzel coefficient
 *                    (12 fractional bits)
 */
int32_t goertzel_coeff(int32_t freq, int32_t sfreq) {

    // omega as a mapped value in [0, 0x8000]
    int32_t omega = (((freq << 15) / sfreq) * 0x8000) >> 15;

    // cosine returns 4.12 fp, so coeff is 4.12 fp
    return 2 * cos_fp(omega);
}


/**
 * Goertzel Algorithm Implementation
 *
 * based on https://github.com/OmaymaS/DTMF-Detection-Goertzel-Algorithm-
 * @param samples[]     collected time series samples to process
 * @param freq          target frequency
 * @param sfreq         sampling frequency
 * @param N             number of samples
 * @return              32-bit fixed point squared magnitude (power) of the target tone
 *                        in the given sampling window
 */
int32_t goertzel_pow(int16_t samples[], int32_t coeff, int32_t N) {
    // declare and initialize variables
    int32_t Q0, Q1 = 0, Q2 = 0, i;
    int32_t prod1, prod2, prod3, pow = 0;

    for (i = 0; i < N; i++) {
        // loop N times and calculate Q0, Q1, Q2 in each iteration
        // 12 bit shift to account for fixed point
        Q0 = (samples[i]) + ((coeff * Q1) >> 12) - Q2;
        Q2 = Q1;
        Q1 = Q0;
    }

    // calculate products for power
    prod1 = Q1 * Q1;
    prod2 = Q2 * Q2;
    prod3 = ((Q1 * coeff) >> 12) * Q2;

    pow = (prod1 + prod2 - prod3);

    return pow;
}


