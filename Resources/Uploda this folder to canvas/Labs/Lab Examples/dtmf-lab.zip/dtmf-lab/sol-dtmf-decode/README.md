# DTMF Decode Solution

This implements part 1 of Lab 4: DTMF decoding.

The CC3200 samples the ADC at 16kHz and then processes sample blocks of 410 samples with the Goertzel Algorithm.

Unlike the recommended usage of lookup tables for computing Goertzel coefficients, I instead implement it with an accurate approximation of the sine function using polynomial approximation. Rather than 14 fractional bits, I use 12 because that is what the approximation function uses. 

Because of this, there are a few significant differences between my code and the one recommended in the instructions.

I think students who can figure out fixed point approximation deserve extra credit.